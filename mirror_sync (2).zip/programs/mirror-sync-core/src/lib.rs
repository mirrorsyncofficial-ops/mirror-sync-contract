use anchor_lang::prelude::*;

// Placeholder ID - replace with new ID after deploy
declare_id!("HqgtRykyVLCYEPWYt4HHovRiTitUyMJ1aCtsaKfoTuR6");

#[program]
pub mod mirror_sync_core {
    use super::*;

    pub fn initialize(ctx: Context<Initialize>) -> Result<()> {
        msg!("MirrorSyncCore initialized!");
        Ok(())
    }

    pub fn mirror_trade(ctx: Context<MirrorTrade>, amount: u64) -> Result<()> {
        msg!("Mirroring {} lamports from trader to follower", amount);
        // Mock function - no actual transfer yet
        Ok(())
    }
}

#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(mut)]
    pub initializer: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct MirrorTrade<'info> {
    #[account(mut)]
    pub trader: Signer<'info>, // Trader initiates the trade
    #[account(mut)]
    pub follower: AccountInfo<'info>, // Follower receives mirrored action
    pub system_program: Program<'info, System>,
}
